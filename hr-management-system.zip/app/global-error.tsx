"use client"

import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <html>
      <body>
        <div className="min-h-screen flex items-center justify-center bg-background">
          <div className="text-center space-y-6 max-w-md mx-auto px-4">
            {/* Error Icon */}
            <div className="flex justify-center">
              <div className="relative">
                <div className="text-6xl font-bold text-destructive/20 select-none">ERROR</div>
                <div className="absolute -top-2 -right-2 flex space-x-1">
                  <div className="w-2 h-2 bg-destructive rounded-full animate-pulse"></div>
                  <div className="w-2 h-2 bg-destructive/70 rounded-full animate-pulse delay-100"></div>
                </div>
              </div>
            </div>

            {/* Error Message */}
            <div className="space-y-2">
              <h1 className="text-2xl font-semibold text-foreground">Something went wrong!</h1>
              <p className="text-muted-foreground">An unexpected error occurred. Please try again.</p>
            </div>

            {/* Action Button */}
            <div className="pt-4">
              <Button onClick={reset} variant="outline" className="min-w-32">
                <RefreshCw className="mr-2 h-4 w-4" />
                Try again
              </Button>
            </div>
          </div>
        </div>
      </body>
    </html>
  )
}
