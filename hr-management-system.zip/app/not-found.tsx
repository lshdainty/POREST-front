import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home } from "lucide-react"

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center space-y-6 max-w-md mx-auto px-4">
        {/* 404 Icon/Illustration */}
        <div className="flex justify-center">
          <div className="relative">
            {/* Main 404 graphic */}
            <div className="text-8xl font-bold text-muted-foreground/20 select-none">404</div>
            {/* Decorative dots */}
            <div className="absolute -top-4 -right-4 flex space-x-1">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
              <div className="w-2 h-2 bg-primary/70 rounded-full animate-pulse delay-100"></div>
              <div className="w-2 h-2 bg-primary/50 rounded-full animate-pulse delay-200"></div>
            </div>
            <div className="absolute -bottom-4 -left-4 flex space-x-1">
              <div className="w-2 h-2 bg-primary/50 rounded-full animate-pulse delay-300"></div>
              <div className="w-2 h-2 bg-primary/70 rounded-full animate-pulse delay-400"></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-500"></div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        <div className="space-y-2">
          <h1 className="text-2xl font-semibold text-foreground">Sorry, the page you visited does not exist.</h1>
          <p className="text-muted-foreground">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
        </div>

        {/* Action Button */}
        <div className="pt-4">
          <Button asChild className="min-w-32">
            <Link href="/dashboard">
              <Home className="mr-2 h-4 w-4" />
              Back Home
            </Link>
          </Button>
        </div>

        {/* Additional decorative elements */}
        <div className="pt-8 opacity-30">
          <div className="flex justify-center space-x-8">
            <div className="w-16 h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  )
}
