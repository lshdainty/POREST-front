import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <div className="flex min-h-svh">
      <div className="hidden w-full max-w-md bg-muted lg:block">
        <div className="flex h-full items-center justify-center p-8">
          <div className="relative h-full w-full">
            <div className="absolute inset-0 bg-gradient-to-t from-muted/80 to-muted/20 z-10 rounded-lg"></div>
            <img
              src="/placeholder.svg?height=800&width=600&text=HR+Management"
              alt="HR Management"
              className="h-full w-full rounded-lg object-cover"
              width={600}
              height={800}
            />
            <div className="absolute bottom-8 left-8 right-8 z-20">
              <div className="space-y-2">
                <h2 className="text-xl font-semibold text-white">HR Management System</h2>
                <p className="text-sm text-white/80">
                  Streamline your HR operations with our comprehensive management solution.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-1 items-center justify-center">
        <div className="w-full max-w-md px-8">
          <LoginForm />
        </div>
      </div>
    </div>
  )
}
